# MiniMIPS32
+ logisim 文件可以直接用
+ verilog 只有核心代码，需要自己建工程并且导入 inst_rom data_ram
